public class Main {
    public Main() {
    }
    public static void main(String[] args) {
        Circle circle = new Circle(12.0);
        System.out.println(circle.getSquare());
        System.out.println(circle.getPerimeter());
        Rectangle rectangle = new Rectangle(8.0, 2.0);
        System.out.println(rectangle.getSquare());
        System.out.println(rectangle.getPerimeter());
        Triangle triangle = new Triangle(5.0, 6.0, 3.0);
        System.out.println(triangle.getSquare());
        System.out.println(triangle.getPerimeter());
        Ellipse ellipse = new Ellipse(12.0, 12.0);
        System.out.println(ellipse.getSquare());
        System.out.println(ellipse.getPerimeter());
    }
}