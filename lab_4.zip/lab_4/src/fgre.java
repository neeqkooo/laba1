public interface fgre {
    double getSquare();

    double getPerimeter();
}